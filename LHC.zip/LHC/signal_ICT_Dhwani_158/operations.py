import numpy as np
import matplotlib.pyplot as plt
from scipy import signal

import numpy as np
import matplotlib.pyplot as plt
from scipy import signal

# 1. Time Shift
def time_shift(signal, k, title='Signal Shift', time_vector=None):
    if time_vector is None:
        time_vector = np.arange(len(signal))

    shifted_signal = np.roll(signal, -k)

    plt.figure(figsize=(10, 6))
    plt.plot(time_vector, signal, label='Original Signal', color='blue', alpha=0.7)
    plt.plot(time_vector, shifted_signal, label=f'Shifted by {k} units', color='red', linestyle='--')
    plt.title(title)
    plt.xlabel('Time')
    plt.ylabel('Amplitude')
    plt.legend()
    plt.grid(True)
    plt.show()

# 2. Time Scale
def time_scale(original_signal, time_vector2, k, title='Signal Time Scaling'):
    num_samples_original = len(original_signal)
    num_samples_scaled = int(num_samples_original / k)

    scaled_signal = signal.resample(original_signal, num_samples_scaled)
    scaled_time_vector = np.linspace(time_vector2[0] * k, time_vector2[-1] * k, num_samples_scaled)

    plt.figure(figsize=(10, 6))
    plt.plot(time_vector2, original_signal, label='Original Signal', color='blue', alpha=0.7)
    plt.plot(scaled_time_vector, scaled_signal, label=f'Scaled by k={k}', color='red', linestyle='--')
    plt.title(title)
    plt.xlabel('Time')
    plt.ylabel('Amplitude')
    plt.legend()
    plt.grid(True)
    plt.show()

# 3. Signal Addition
def signal_addition(signal1, signal2, time_vector=None):
    if len(signal1) != len(signal2):
        raise ValueError("Signals must have the same length for addition.")

    combined_signal = signal1 + signal2

    if time_vector is None:
        time_vector = np.arange(len(signal1))

    plt.figure(figsize=(12, 8))
    plt.plot(time_vector, signal1, label='Signal 1', color='blue', alpha=0.7)
    plt.plot(time_vector, signal2, label='Signal 2', color='green', alpha=0.7)
    plt.plot(time_vector, combined_signal, label='Combined Signal (Sum)', color='red', linestyle='--', linewidth=2)
    plt.title('Signal Addition')
    plt.xlabel('Time')
    plt.ylabel('Amplitude')
    plt.legend()
    plt.grid(True)
    plt.show()

    return combined_signal

# 4. Signal Multiplication
def signal_multiplication(signal1, signal2, time_vector=None):
    if len(signal1) != len(signal2):
        raise ValueError("Signals must have the same length for point-wise multiplication.")

    multiplied_signal = signal1 * signal2

    if time_vector is None:
        time_vector = np.arange(len(signal1))

    fig, axs = plt.subplots(3, 1, figsize=(10, 10), sharex=True)

    axs[0].plot(time_vector, signal1, color='blue')
    axs[0].set_title('Signal 1')
    axs[0].set_ylabel('Amplitude')
    axs[0].grid(True)

    axs[1].plot(time_vector, signal2, color='green')
    axs[1].set_title('Signal 2')
    axs[1].set_ylabel('Amplitude')
    axs[1].grid(True)

    axs[2].plot(time_vector, multiplied_signal, color='red', linestyle='--', linewidth=2)
    axs[2].set_title('Multiplied Signal')
    axs[2].set_xlabel('Time')
    axs[2].set_ylabel('Amplitude')
    axs[2].grid(True)

    plt.tight_layout()
    plt.show()

    return multiplied_signal