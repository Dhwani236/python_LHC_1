from setuptools import setup, find_packages

setup(
    name='signal_ICT_Dhwani_158',
    version='0.1.1',
    packages=find_packages(),
    install_requires=[
        'numpy',
        'matplotlib',
        'scipy'
    ],
    author='Dhwani',
    description='A Python package for visualizing and manipulating signals using matplotlib',
    long_description=open('README.md').read(),
    long_description_content_type='text/markdown',
    classifiers=[
        'Programming Language :: Python :: 3',
        'Operating System :: OS Independent',
    ],
)