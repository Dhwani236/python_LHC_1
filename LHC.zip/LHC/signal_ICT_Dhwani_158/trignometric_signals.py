import numpy as np
import matplotlib.pyplot as plt 

# Sine function
def sine_wave(A, f, phi, t, title='Sine Wave'):
    # Generate the sine wave data based on the formula: A * sin(2*pi*f*t + phi)
    y = A * np.sin(2 * np.pi * f * t + phi)

    # Plot the sine wave
    plt.figure(figsize=(10, 6))
    plt.plot(t, y)
    plt.title(title)
    plt.xlabel('Time (s)')
    plt.ylabel('Amplitude')
    plt.grid(True)
    plt.axhline(y=0, color='k', linestyle='--')  # Adds a horizontal line at y=0
    plt.show()

# Cosine function
def cosine_wave(A, f, phi, t, title='Cosine Wave'):
    # Generate the cosine wave data based on the formula: A * cos(2*pi*f*t + phi)
    y = A * np.cos(2 * np.pi * f * t + phi)

    # Plot the cosine wave
    plt.figure(figsize=(10, 6))
    plt.plot(t, y)
    plt.title(title)
    plt.xlabel('Time (s)')
    plt.ylabel('Amplitude')
    plt.grid(True)
    plt.axhline(y=0, color='k', linestyle='--')  # Adds a horizontal line at y=0
    plt.show()

# Exponential function
def exponential_signal(A, a, t, title='Exponential Signal'):
    # Generate the exponential signal data using the formula: y = A * e^(a*t)
    y = A * np.exp(a * t)

    # Plot the exponential signal
    plt.figure(figsize=(10, 6))
    plt.plot(t, y)
    plt.title(title)
    plt.xlabel('Time (s)')
    plt.ylabel('Amplitude')
    plt.grid(True)
    plt.axhline(y=0, color='k', linestyle='--')  # Adds a horizontal line at y=0
    plt.show()