 #geneartion of unit step, unit impulse and ramp functions are done by inbuilt functions within the NumPy library 
# what are we doing? we are using those functions to generate the signals and then plotting them using matplotlib 
# so we are creating this module to visulise different signals by integrating functions of NumPy and Matplotlib 
# each function created by me visulises one signal using the inbuilt signal generation functions and Matplotlib 

import numpy as np
import matplotlib.pyplot as plt

# 1. Define the unit step function
def unit_step(t):
    y_values = np.heaviside(t, 1)  # Returns 0 for t<0 and 1 for t>=0
    plt.plot(t, y_values)
    plt.title("Unit Step Function")
    plt.xlabel("Time (t)")
    plt.ylabel("Amplitude (u(t))")
    plt.grid(True)
    plt.show()

# Unit impulse function
def unit_impulse(t2):
    y2_values = np.where(t2 == 0, 1, 0)
    plt.scatter(t2, y2_values)
    plt.title("Unit Impulse Function")
    plt.xlabel("Time (t)")
    plt.ylabel("Amplitude (u(t))")
    plt.grid(True)
    plt.show()

# Unit ramp function
def unit_ramp(t3):
    y3_values = np.where(t3 >= 0, t3, 0)
    plt.plot(t3, y3_values)
    plt.title("Unit Ramp Function")
    plt.xlabel("Time (t)")
    plt.ylabel("Amplitude (u(t))")
    plt.grid(True)
    plt.show()