import signal_ICT_Dhwani_158
import numpy as np
from signal_ICT_Dhwani_158 import *


# 1. Generate and plot a unit step signal and a unit impulse signal of length 20
t1 = np.linspace(-10, 10, 20)
unit_step(t1)
unit_impulse(t1)

# 2. Generate a sine wave of amplitude 2, frequency 5 Hz, phase 0, over t = 0 to 1 sec
t2 = np.linspace(0, 1, 500)
A = 2
f = 5
phi = 0
sine_wave(A, f, phi, t2, title='Sine Wave: A=2, f=5Hz, φ=0')

# 3. Perform time shifting on the sine wave by +5 units and plot both original and shifted signals
original_signal = A * np.sin(2 * np.pi * f * t2 + phi)
time_shift(original_signal, k=5, title='Sine Wave Shifted by +5 Units', time_vector=t2)

# 4. Perform addition of the unit step and ramp signal and plot the result
t3 = np.linspace(-10, 10, 100)
step = np.heaviside(t3, 1)
ramp = np.where(t3 >= 0, t3, 0)
signal_addition(step, ramp, time_vector=t3)

# 5. Multiply a sine and cosine wave of same frequency and plot the result
frequency = 2
t4 = np.linspace(0, 2, 500)
sine_sig = np.sin(2 * np.pi * frequency * t4)
cosine_sig = np.cos(2 * np.pi * frequency * t4)
signal_multiplication(sine_sig, cosine_sig, time_vector=t4)